// ===============================================================
// ملف إعداد وتهيئة الاتصال بـ Firebase (Firestore & Authentication)
// المسار المقترح: public/js/firebase-config.js
// مشروع: النظام المالي والمحاسبي الموحد - كنيسة الأنبا صموئيل المعترف
// ===============================================================

// 1. استيراد حزم Firebase SDK الرسمية عبر الـ CDN
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { 
  getFirestore, 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  addDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  serverTimestamp,
  increment 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

import { 
  getAuth, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

// 2. إعدادات ومفاتيح مشروع Firebase الخاص بكنيسة الأنبا صموئيل
// (يمكنك الحصول على هذه القيم من إعدادات المشروع داخل Firebase Console > Project Settings)
const firebaseConfig = {
  apiKey: "AIzaSy_YOUR_API_KEY_HERE",
  authDomain: "church-samuel-finance.firebaseapp.com",
  projectId: "church-samuel-finance",
  storageBucket: "church-samuel-finance.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef1234567890"
};

// 3. تهيئة التطبيق ومصادقة الاتصال
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

// ===============================================================
// دوال مساعدة جاهزة لإدارة العمليات المالية والمخزون في النظام
// ===============================================================

/**
 * تسجيل فاتورة جديدة وخصم المخزون وزيادة رصيد الخزينة تلقائياً
 */
export async function createInvoiceAndUpdateStock({
  sectorId,      // معرف القسم (مثل: 'poultry_farm', 'library', 'buses')
  itemId,        // معرف الصنف
  quantity,      // الكمية المباعة
  unitPrice,     // سعر الوحدة
  totalAmount,   // إجمالي الفاتورة
  cashierName    // اسم الخادم / أمين الصندوق
}) {
  try {
    // 1. إضافة سجل الفاتورة في مجموعة transactions
    const invoiceRef = await addDoc(collection(db, "transactions"), {
      sector_id: sectorId,
      item_id: itemId,
      quantity: Number(quantity),
      unit_price: Number(unitPrice),
      total_amount: Number(totalAmount),
      created_by: cashierName,
      created_at: serverTimestamp()
    });

    // 2. خصم الكمية من رصيد المخزون في مجموعة items
    if (itemId) {
      const itemDocRef = doc(db, "items", itemId);
      await updateDoc(itemDocRef, {
        current_quantity: increment(-Number(quantity))
      });
    }

    // 3. ترحيل المبلغ وزيادة رصيد الخزينة وإجمالي الإيرادات في مجموعة sectors
    if (sectorId) {
      const sectorDocRef = doc(db, "sectors", sectorId);
      await updateDoc(sectorDocRef, {
        cash_balance: increment(Number(totalAmount)),
        total_revenue: increment(Number(totalAmount))
      });
    }

    return { success: true, invoiceId: invoiceRef.id };
  } catch (error) {
    console.error("خطأ في تسجيل الفاتورة وترحيل الأرصدة:", error);
    throw error;
  }
}

/**
 * مراقبة رصيد خزينة قسم معين وتحديث الواجهة لحظياً (Real-time Listener)
 */
export function listenToSectorBalance(sectorId, callback) {
  const sectorDocRef = doc(db, "sectors", sectorId);
  return onSnapshot(sectorDocRef, (docSnap) => {
    if (docSnap.exists()) {
      callback(docSnap.data());
    }
  });
}
